maze_name = "Command Line Corn Maze"
your_name = "Ellis Lee" 

instructions = This is a command-line maze created for the Lost & Found assignment.\n\n## Instructions to Solve the Maze:\n1. Use the 'cd' command to navigate through the directories.\n2. Use 'ls' or 'ls -la' to list the contents of each directory.\n3. Read the clues provided in the files to find your way. To read a file, use 'cat filename.txt'.


